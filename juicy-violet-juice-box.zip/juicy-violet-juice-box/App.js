import React from "react";
import AppLayout from "./app/_layout";

export default function App() {
  return <AppLayout />;
}
